import random
import string

def guess_check(guess):
    try:
        str(guess)
        return True
    except:
        return False
    
def level_check(difficulty):
    try:
        int(difficulty)
        return True
    except:
        return False
    
def asking_difficulty(valid_input):
    while True:
        difficulty = input("Choose your difficulty Level, starting level 1 to 3: ")
        if level_check(difficulty) and difficulty == '1' or difficulty == '2' or difficulty == '3' :
            return int(difficulty)
        else:
            if not level_check(difficulty):
                return None
            print("wrong input")
            
